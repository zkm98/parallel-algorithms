#include<time.h>
#include<iostream>
//#include<Windows.h>
#include<sys/time.h>
#include<cmath>
#include"SIMDLib/gcc_api.h"
#include<algorithm>
#include<omp.h>
#define RADIX 8    
#define KEYNUM 5   

void sort_gen(int *d, int N, int seed) {
	srand(seed);
	for (int i = 0; i < N; i++) {
		d[i] = rand();
	}
}
int cmp(const void * a, const void * b) {
	return(*(int *)a - *(int *)b);
}
#define MAXlen 10
int getpos(int a, int radix, int pos) {
	int path = pow(radix, pos - 1);
	int p = a / path;
	p = p % radix;
	return p;
}
int getpos2(int a, int radix, int pos) {
	int path = pow(radix, pos);
	int p = a / path;
	p = p % radix;
	return p;
}
inline int GetDigitInPos(int num, int pos)
{
	int temp = 1;
	for (int i = 0; i < pos - 1; i++)
		temp *= 10;
	return (num / temp) % 10;
}


typedef struct bash {
	int val;
	bash *next;
}bash, *pbash;
void Radixsort(int *a, int N, int Radix, int k, int maxlen) {
	int **radixArrays = new int*[Radix];
	for (int i = 0; i < Radix; i++) {
		radixArrays[i] = new int[k + 1]{ 0 };
		int sum = 0;
	}

	for (int pos = 1; pos <= maxlen; pos++) {
		for (int i = 0; i < N; i++) {
			if (a[i] < 0) {
				printf("pos:%d,num%d\n\n", pos, a[i]);
			}

			int k = pow(Radix, pos);
			int index = a[i] % k;
			index = index * Radix / k;

			radixArrays[index][0]++;

			int inde = radixArrays[index][0];
			radixArrays[index][inde] = a[i];
		}
		for (int i = 0, j = 0; i < Radix; i++) {
			for (int k1 = 1; k1 <= radixArrays[i][0]; k1++) {
				a[j++] = radixArrays[i][k1];
			}
			radixArrays[i][0] = 0;
		}

	}

}
void Radixsorts(int *a, int N, int Radix, int k, int maxlen) {
	bash **barrelhead = new bash*[Radix];
	bash **barreltail = new bash*[Radix];
	for (int i = 0; i < Radix; i++) {
		barrelhead[i] = new bash;
		barreltail[i] = barrelhead[i];
	}

	for (int pos = 1; pos <= maxlen; pos++) {
		//#pragma omp parallel for num_threads(10)
		for (int i = 0; i < N; i++) {
			int index = GetDigitInPos(a[i], pos);
			bash* pnew = new bash;
			pnew->val = a[i];

			barreltail[index]->next = pnew;
			pnew->next = NULL;
			barreltail[index] = pnew;
		}

		int i = 0, j = 0;
#pragma omp single 
		for (; i < Radix; i++)
		{
			bash* p = barrelhead[i]->next;
			bash *temp;
			while (p != NULL) {
				a[j++] = p->val;
				temp = p;
				p = p->next;
				free(temp);
			}
			barrelhead[i]->val = -1;
			barrelhead[i]->next = NULL;
			barreltail[i] = barrelhead[i];
		}

	}

}

inline void pRadixSort(int* unorderArray, int offset, int dataNum ,int radix,int keynum)
{
	int *radixArrays[radix];    //�ֱ�Ϊ0~9�����Ĵ�ſռ�  
	for (int i = 0; i < 10; i++)
	{
		radixArrays[i] = (int *)malloc(sizeof(int)*(dataNum + 1));
		radixArrays[i][0] = 0;    //indexΪ0����¼�������ݵĸ���  
	}
	for (int pos = 1; pos <= keynum; pos++)   //�Ӹ�λ��ʼ��Ͱ����Ͱ
	{
		for (int i = 0; i < dataNum; i++)    //�������  
		{
			int num = GetDigitInPos(unorderArray[i + offset], pos);
			int index = ++radixArrays[num][0];
			radixArrays[num][index] = unorderArray[i + offset];
		}
		for (int i = 0, j = 0; i < radix; i++)//�ռ�  
		{
			for (int k = 1; k <= radixArrays[i][0]; k++)
				unorderArray[offset + j++] = radixArrays[i][k];
			radixArrays[i][0] = 0;    //��Ͱ��ϣ���λ  
		}
	}
}

#define DataNum 1000000000
int threadNum = 0;
void* radix_exec(void *para)
{
	int threadIndex = *(int*)para;
	int blockLen = DataNum / threadNum;
	int offset = threadIndex * blockLen;
	pRadixSort(randInt, offset, blockLen,8,5);
}
inline void mergeBlocks(int* const pDataArray, int arrayLen, const int blockNum, int* const resultArray)
{
	int blockLen = arrayLen / blockNum;
	int blockIndex[blockNum];//��������Ԫ���������е��±꣬VC���ܲ�֧�ֱ�����Ϊ����ĳ��ȣ�����취��ʹ�ú궨��
	for (int i = 0; i < blockNum; ++i)//��ʼ������Ԫ����ʼ�±�
	{
		blockIndex[i] = i * blockLen;
	}
	int smallest = 0;
	for (int i = 0; i < arrayLen; ++i)//ɨ�����п��ڵ�����Ԫ��
	{
		for (int j = 0; j < blockNum; ++j)//�Ե�һ��δɨ����Ŀ���Ԫ����Ϊ��С��
		{
			if (blockIndex[j] < (j*blockLen + blockLen))
			{
				smallest = pDataArray[blockIndex[j]];
				break;
			}
		}
		for (int j = 0; j < blockNum; ++j)//ɨ������飬Ѱ����С��
		{
			if ((blockIndex[j] < (j*blockLen + blockLen)) && (pDataArray[blockIndex[j]] < smallest))
			{
				smallest = pDataArray[blockIndex[j]];
			}
		}
		for (int j = 0; j < blockNum; ++j)//ȷ���ĸ�����Ԫ���±��������
		{
			if ((blockIndex[j] < (j*blockLen + blockLen)) && (pDataArray[blockIndex[j]] == smallest))
			{
				++blockIndex[j];
				break;
			}
		}
		resultArray[i] = smallest;//����ѭ����С������������
	}
}
int main1(int argc, char* argv[])
{
	int threadBum = 8;
	int blockNum = threadNum;
	struct timeval ts, te;
	srand(time(NULL));
	cout << "RAND_MAX:" << RAND_MAX << endl;
	for (int i = 0; i < DataNum; ++i)
	{
		randInt[i] = rand();
	}
	pthread_t tid[blockNum], ret[blockNum], threadIndex[blockNum];

	//--------Radix sort-------
	gettimeofday(&ts, NULL);
	for (int i = 0; i < threadNum; ++i)
	{
		threadIndex[i] = i;
		ret[i] = pthread_create(&tid[i], NULL, radix_exec, (void *)(threadIndex + i));
		if (ret[i] != 0) {
			cout << "thread " << i << " create error!" << endl;
			break;
		}
	}
	for (int i = 0; i < threadNum; ++i)
	{
		pthread_join(tid[i], NULL);
	}
	mergeBlocks(randInt, DataNum, threadNum, resultInt);
	gettimeofday(&te, NULL);
	cout << "RadixSort time: " << (te.tv_sec - ts.tv_sec) * 1000 + (te.tv_usec - ts.tv_usec) / 1000 << "ms" << endl;
}


void main() {
	int seed = 45;
	const int N = 1000000000;
	int *a = new int[N];
	sort_gen(a, N, seed);
	timeval start;
	timeval end;
	unsigned long diff;
	
	sort_gen(a, N, seed);
	gettimeofday(&start, NULL);
	Radixsort(a, N, 7, N / 6, 5);
	gettimeofday(&end, NULL);
	diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
	printf("Radixsort: the time with N = %d is %ldms\n", N, diff);
	printf("%d\n", a[N / 2]);

	sort_gen(a, N, seed);
	gettimeofday(&start, NULL);
	Radixsort(a, N, 8, N / 7, 5);
	gettimeofday(&end, NULL);
	diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
	printf("Radixsort: the time with N = %d is %ldms\n", N, diff);
	printf("%d\n", a[N/2]);

	

	sort_gen(a, N, seed);
	gettimeofday(&start, NULL);
	Radixsort(a, N, 9, N / 2, 5);
	gettimeofday(&end, NULL);
	diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
	printf("Radixsort: the time with N = %d is %ldms\n", N, diff);
	printf("%d\n", a[N / 2]);

	sort_gen(a, N, seed);
	gettimeofday(&start, NULL);
	qsort(a, N, 4, cmp);
	gettimeofday(&end, NULL);
	diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
	printf("quicksort: the time with N = %d is %ldms\n", N, diff);
	printf("%d\n", a[5000000]);

	main1();
	char g = getchar();
}