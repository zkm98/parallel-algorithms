#include<omp.h>
#include<iostream>
//#include<Windows.h>
#include<sys/time.h>
#include <xmmintrin.h>
#include <tmmintrin.h>
#include <immintrin.h>
using namespace std;


float rand_float(float s) {

	return 4 * s*(1 - s);
}
void matrix_gen(float *a, float *b, int N, float seed) {
	float s = seed;
	for (int i = 0; i < N*N; i++) {
		s = rand_float(s);
		a[i] = s;
		s = rand_float(s);
		b[i] = s;
	}
}

int main() {
	int N;
	float seed;
	N = 8192;
	seed = 0.3;
	int sub_size = 64;
	while (N < 8193) {
		float *A = new float[N*N];
		float *B = new float[N*N];
		matrix_gen(A, B, N, seed);
		

		timeval start;
		timeval end;
		unsigned long diff;
		gettimeofday(&start, NULL);

		int sub_num = N / sub_size;
		int sn = sub_num * sub_num;
		int size = sub_size * sub_size;
		float **mat_A = new float *[sn];
		float **mat_B = new float *[sn];
		float **mat_C = new float *[sn];

		for (int i = 0; i < sn; i++) {
			mat_A[i] = new float[size];
			mat_B[i] = new float[size];
			mat_C[i] = new float[size] {0.0};
		}

		for (int r = 0; r < N*N; r++) {
			int i = r / (N*sub_size);
			int j = ((r - (int)(r/N)*N) / sub_size);
			int mi=r/N-i*sub_size;
			int mj=r-N*(int)(r/N)-j*sub_size;
			mat_A[i*sub_num + j][mi*sub_size + mj] = A[r];
			mat_B[i*sub_num+j][mi*sub_size+mj] = B[r];
		}
		delete A, B;
		cout << "fin" << endl;

		for (int k1 = 0; k1 < sub_num; k1++) {
			int kp = k1 * sub_num;
#pragma omp parallel for num_threads(12)
			for (int i1 = 0; i1 < sub_num; i1++) {
				int im = i1 * sub_num;
				int Aik = im + k1;//��������ʱ��A��λ��
				for (int j1 = 0; j1 < sub_num; j1++) {
					//����������Ϊ�˼����i�У�j�е�C����
					//Ҳ���Ǽ���mat_Cij�������ʹ�õ���mat_Aik_C**mat_Bk_Cj
					//��Ϊ����ʹ�õ�˹kij������������k�ξ���ӷ�ȥ��
					//�õ�һ��mat_Cij+=mat_Aik_C*mat_Bk_Cj
					int Cij = im + j1;//��������ʱ��C��λ��
					int Bkj = kp + j1;//��������ʱ��B��λ��s
					for (int k = 0; k < sub_size; k++) {
						int kk = k * sub_size;
						for (int i = 0; i < sub_size; i++) {
							int ii = i * sub_size;
							float r = A[ik][ii + k];
							for (int j = 0; j < sub_size; j++) {
								C[Cij][ii + j] += r * B[Bkj][kk + j];
							}
						}
					}
						
				}
			}
		}

		gettimeofday(&end, NULL);
		diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;

		printf("the time with N = %d is %ld\n", N, diff);

		float trace = 0.0;
		for (int i = 0; i < sub_num; i++) {
			int i_co = i * sub_num+i;
			for (int j = 0; j < sub_size; j++) {
				trace += mat_C[i_co][j*sub_size + j];
			}
		}
		printf("the trace with N is %d kij is %f\n", N, trace);
		N *= 2;
		
	}

	system("PAUSE");
	return 0;
}
