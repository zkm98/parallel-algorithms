#include<omp.h>
#include<iostream>
#include<Windows.h>
//#include<sys/time.h>
#include <xmmintrin.h>
#include <tmmintrin.h>
#include <immintrin.h>
#include<intrin.h>
#include<algorithm>
#include<vector>
using namespace std;
#define BATCH 4
void norm(float*, float*, int);
float* add(float*A, float*B,int n) {
	float *result = new float[n*n];
	for (int i = 0; i < n; i++) {
		int ii = i * n;
		for (int j = 0; j < n; j++) {
			result[ii + j] = A[ii + j] + B[ii + j];
		}
	}
	return result;
}
float* mie(float*A, float*B, int n) {
	float *result = new float[n*n];
	for (int i = 0; i < n; i++) {
		int ii = i * n;
		for (int j = 0; j < n; j++) {
			result[ii + j] = A[ii + j] - B[ii + j];
		}
	}
	return result;
}
float* mul(float*A, float*B, int n) {
	float *result = new float[n*n]{ 0.0 };
	for (int k = 0; k < n; ++k) {
		int kk = k * n;
#pragma omp parallel for num_threads(12)
		for (int i = 0; i < n; i++) {
			int ii = i * n;
			float r = A[ii + k];
			for (int j = 0; j < n; j++) {
				result[ii + j] += r * B[kk + j];

			}
		}
	}
	return result;
}

float** add(float**A, float**B, int n) {
	float **result = new float*[n];
	for (int i = 0; i < n; i++) {
		result[i] = new float[n];
		for (int j = 0; j < n; j++) {
			result[i][j] = A[i][j] + B[i][j];
		}
	}
	return result;
}
float** mie(float**A, float**B, int n) {
	float **result = new float*[n];
	for (int i = 0; i < n; i++) {
		result[i] = new float[n];
		for (int j = 0; j < n; j++) {
			result[i][j] = A[i][j] - B[i][j];
		}
	}
	return result;
}
float** mul(float**A, float**B, int n) {
	float **result = new float*[n];
	for (int i = 0; i < n; i++)result[i] = new float[n] {0.0};
	for (int k = 0; k < n; ++k) {
		for (int i = 0; i < n; i++) {
			float r = A[i][k];

			for (int j = 0; j < n; j++) {
				result[i][j] += r * B[k][j];
			}
		}
	}
	return result;
}

static void mm_winograd(float* matA, float* matB, float* matC, const int M, const int N, const int K,
	const int strideA, const int strideB, const int strideC)
{
	if ((M <= 64) || (M % 2 != 0 || N % 2 != 0 || K % 2 != 0))
	{
		norm(matA,matB,N);
		return;
	}
	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

	memset(matC, 0, M*strideC * sizeof(float));
	int offset = 0;

	std::vector<float> S1((M / 2) * (K / 2));
	std::vector<float> S2((M / 2) * (K / 2));
	std::vector<float> S3((M / 2) * (K / 2));
	std::vector<float> S4((M / 2) * (K / 2));
	for (int i = 0; i < M / 2; i++)
	{
		for (int j = 0; j < K / 2; j++)
		{
			const int idx = i * K / 2 + j;
			//S1 = A21 + A22
			S1[idx] = matA[(i + M / 2)*strideA + j] + matA[(i + M / 2)*strideA + j + K / 2];
			//S2 = S1 - A11
			S2[idx] = S1[idx] - matA[i*strideA + j];
			//S3 = A11 - A21
			S3[idx] = matA[i*strideA + j] - matA[(i + M / 2)*strideA + j];
			//S4 = A12 - S2
			S4[idx] = matA[i*strideA + j + K / 2] - S2[idx];
		}
	}
	std::vector<float> T1((K / 2) * (N / 2));
	std::vector<float> T2((K / 2) * (N / 2));
	std::vector<float> T3((K / 2) * (N / 2));
	std::vector<float> T4((K / 2) * (N / 2));
	for (int i = 0; i < K / 2; i++)
	{
		for (int j = 0; j < N / 2; j++)
		{
			const int idx = i * N / 2 + j;
			//T1 = B21 - B11
			T1[idx] = matB[(i + K / 2)*strideB + j] - matB[i*strideB + j];
			//T2 = B22 - T1
			T2[idx] = matB[(i + K / 2)*strideB + j + N / 2] - T1[idx];
			//T3 = B22 - B12
			T3[idx] = matB[(i + K / 2)*strideB + j + N / 2] - matB[i*strideB + j + N / 2];
			//T4 = T2 - B21
			T4[idx] = T2[idx] - matB[(i + K / 2)*strideB + j];
		}
	}

	//M1 = A11*B11
	std::vector<float> M1((M / 2) * (N / 2));
	{
		memset(&M1[0], 0, M1.size() * sizeof(float));
		mm_winograd(matA, matB, &M1[0], M / 2, N / 2, K / 2,
			strideA, strideB, N / 2);
	}

	//M2 = A12*B21
	std::vector<float> M2((M / 2) * (N / 2));
	{
		memset(&M2[0], 0, M2.size() * sizeof(float));
		mm_winograd(matA + K / 2, matB + K * strideB / 2, &M2[0], M / 2, N / 2, K / 2,
			strideA, strideB, N / 2);
	}

	//M3 = S4*B22
	std::vector<float> M3((M / 2) * (N / 2));
	{
		memset(&M3[0], 0, M3.size() * sizeof(float));
		mm_winograd(&S4[0], matB + K * strideB / 2 + N / 2, &M3[0], M / 2, N / 2, K / 2,
			K / 2, strideB, N / 2);
	}

	//M4 = A22*T4
	std::vector<float> M4((M / 2) * (N / 2));
	{
		memset(&M4[0], 0, M4.size() * sizeof(float));
		mm_winograd(matA + M * strideA / 2 + K / 2, &T4[0], &M4[0], M / 2, N / 2, K / 2,
			strideA, N / 2, N / 2);
	}

	//M5 = S1*T1
	std::vector<float> M5((M / 2) * (N / 2));
	{
		memset(&M5[0], 0, M5.size() * sizeof(float));
		mm_winograd(&S1[0], &T1[0], &M5[0], M / 2, N / 2, K / 2,
			K / 2, N / 2, N / 2);
	}

	//M6 = S2*T2
	std::vector<float> M6((M / 2) * (N / 2));
	{
		memset(&M6[0], 0, M6.size() * sizeof(float));
		mm_winograd(&S2[0], &T2[0], &M6[0], M / 2, N / 2, K / 2,
			K / 2, N / 2, N / 2);
	}

	//M7 = S3*T3
	std::vector<float> M7((M / 2) * (N / 2));
	{
		memset(&M7[0], 0, M7.size() * sizeof(float));
		mm_winograd(&S3[0], &T3[0], &M7[0], M / 2, N / 2, K / 2,
			K / 2, N / 2, N / 2);
	}

	for (int i = 0; i < M / 2; i++)
	{
		for (int j = 0; j < N / 2; j++)
		{
			const int idx = i * N / 2 + j;
			//U1 = M1 + M2
			const auto U1 = M1[idx] + M2[idx];
			//U2 = M1 + M6
			const auto U2 = M1[idx] + M6[idx];
			//U3 = U2 + M7
			const auto U3 = U2 + M7[idx];
			//U4 = U2 + M5
			const auto U4 = U2 + M5[idx];
			//U5 = U4 + M3
			const auto U5 = U4 + M3[idx];
			//U6 = U3 - M4
			const auto U6 = U3 - M4[idx];
			//U7 = U3 + M5
			const auto U7 = U3 + M5[idx];

			//C11 = U1
			matC[i*strideC + j] = U1;
			//C12 = U5
			matC[i*strideC + j + N / 2] = U5;
			//C21 = U6
			matC[(i + M / 2)*strideC + j] = U6;
			//C22 = U7
			matC[(i + M / 2)*strideC + j + N / 2] = U7;
		}
	}

	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way kij\nthe time with N = %d is %ldms\n", N, diff);


	//printf("the difference with N is %d kij is %ld\n", N, diff);
	float trace = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	for (int i = 0; i < N; i++) {
		trace += matC[i*N + i];
	}

	printf("the trace with N is %d kij is %f\n", N, trace);

}
void strassen(float *A, float *B, int N) {
	int half_N = N / 2;
	
	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

	float **C = new float*[4];
	C[0] = new float[N*N / 4]{ 0.0 };
	C[1] = new float[N*N / 4]{ 0.0 };
	C[2] = new float[N*N / 4]{ 0.0 };
	C[3] = new float[N*N / 4]{ 0.0 };
	float **M = new float*[7];
	M[0] = new float[N*N / 4]{ 0.0 };
	M[1] = new float[N*N / 4]{ 0.0 };
	M[2] = new float[N*N / 4]{ 0.0 };
	M[3] = new float[N*N / 4]{ 0.0 };
	M[4] = new float[N*N / 4]{ 0.0 };
	M[5] = new float[N*N / 4]{ 0.0 };
	M[6] = new float[N*N / 4]{ 0.0 };
	float **A_M = new float*[4];
	float **B_M = new float*[4];
	A_M[0] = new float[N*N / 4];
	A_M[1] = new float[N*N / 4];
	A_M[2] = new float[N*N / 4];
	A_M[3] = new float[N*N / 4];
	B_M[0] = new float[N*N / 4];
	B_M[1] = new float[N*N / 4];
	B_M[2] = new float[N*N / 4];
	B_M[3] = new float[N*N / 4];
	
	int stride = N * half_N;
	int str = stride + half_N;
	for (int k = 0; k < half_N; k++) {
		int kk = k * half_N;
		for (int i = 0; i < half_N; i++) {
			int ii = i * half_N;
			A_M[0][kk+i] = A[kk + i];
			A_M[1][kk+i] = A[kk + i + half_N];
			A_M[2][kk+i] = A[kk + i + stride];
			A_M[3][kk+i] = A[kk + i + str];
			B_M[0][kk+i] = B[kk + i];
			B_M[1][kk+i] = B[kk + i + half_N];
			B_M[2][kk+i] = B[kk + i + stride];
			B_M[3][kk+i] = B[kk + i + str];
		}
	}

	M[0] = mul(add(A_M[0], A_M[3], half_N), add(B_M[0], B_M[3], half_N), half_N);
	M[1] = mul(add(A_M[2], A_M[3], half_N), B_M[0], half_N);
	M[2] = mul(A_M[0], mie(B_M[1], B_M[3], half_N), half_N);
	M[3] = mul(A_M[3], mie(B_M[2], B_M[0], half_N), half_N);
	M[4] = mul(add(A_M[0], A_M[1], half_N), B_M[3], half_N);
	M[5] = mul(mie(A_M[2], A_M[0], half_N), add(B_M[0], B_M[1], half_N), half_N);
	M[6] = mul(mie(A_M[1], A_M[3], half_N), add(B_M[2], B_M[3], half_N), half_N);
	C[0] = add(add(M[0], M[3], half_N), mie(M[6], M[4], half_N), half_N);
	C[1] = add(M[2], M[4], half_N);
	C[2] = add(M[1], M[3], half_N);
	C[3] = add(add(M[0], M[2], half_N), mie(M[5], M[1], half_N), half_N);
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way kij\nthe time with N = %d is %ldms\n", N, diff);
	//printf("the difference with N is %d kij is %ld\n", N, diff);
	float trace = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	for (int i = 0; i <half_N; i++) {
		trace += C[0][i*half_N + i];
		trace += C[3][i*half_N + i];
	}

	printf("the trace with N is %d kij is %f\n", N, trace);
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

	float ****AA = new float***[2];
	float ****BB = new float***[2];
	float ****CC = new float***[2];
	AA[0] = new float**[2];
	AA[1] = new float**[2];
	BB[0] = new float**[2];
	BB[1] = new float**[2];
	CC[0] = new float**[2];
	CC[1] = new float**[2];
	AA[0][0] = new float*[half_N];
	AA[0][1] = new float*[half_N];
	AA[1][0] = new float*[half_N];
	AA[1][1] = new float*[half_N];
	BB[0][0] = new float*[half_N];
	BB[0][1] = new float*[half_N];
	BB[1][0] = new float*[half_N];
	BB[1][1] = new float*[half_N];
	CC[0][0] = new float*[half_N];
	CC[0][1] = new float*[half_N];
	CC[1][0] = new float*[half_N];
	CC[1][1] = new float*[half_N];
	for (int i = 0; i < half_N; i++) {
		AA[0][0][i] = new float[half_N];
		AA[0][1][i] = new float[half_N];
		AA[1][0][i] = new float[half_N];
		AA[1][1][i] = new float[half_N];
		BB[0][0][i] = new float[half_N];
		BB[0][1][i] = new float[half_N];
		BB[1][0][i] = new float[half_N];
		BB[1][1][i] = new float[half_N];
		CC[0][0][i] = new float[half_N] {0.0};
		CC[0][1][i] = new float[half_N] {0.0};
		CC[1][0][i] = new float[half_N] {0.0};
		CC[1][1][i] = new float[half_N] {0.0};
	}

	for (int k = 0; k < half_N; k++) {
		int kk = k * half_N;
		for (int i = 0; i < half_N; i++) {
			int ii = i * half_N;
			AA[0][0][k][i] = A[kk + i];
			AA[0][1][k][i] = A[kk + i + half_N];
			AA[1][0][k][i] = A[kk + i + stride];
			AA[1][1][k][i] = A[kk + i + str];
			BB[0][0][k][i] = B[kk + i];
			BB[0][1][k][i] = B[kk + i + half_N];
			BB[1][0][k][i] = B[kk + i + stride];
			BB[1][1][k][i] = B[kk + i + str];
		}
	}

	float ***MM = new float**[7];
	MM[0] = new float*[half_N];
	MM[1] = new float*[half_N];
	MM[2] = new float*[half_N];
	MM[3] = new float*[half_N];
	MM[4] = new float*[half_N];
	MM[5] = new float*[half_N];
	MM[6] = new float*[half_N];
	for (int i = 0; i < half_N; ++i) {
		MM[0][i]=new float[half_N]{0.0};
		MM[1][i]=new float[half_N]{0.0};
		MM[2][i]=new float[half_N]{0.0};
		MM[3][i]=new float[half_N]{0.0};
		MM[4][i]=new float[half_N]{0.0};
		MM[5][i]=new float[half_N]{0.0};
		MM[6][i]=new float[half_N]{0.0};
	}
	MM[0] = mul(add(AA[0][0], AA[1][1], half_N), add(BB[0][0], BB[1][1], half_N), half_N);
	MM[1] = mul(add(AA[1][0], AA[1][1], half_N), BB[0][0], half_N);
	MM[2] = mul(AA[0][0], mie(BB[0][1], BB[1][1], half_N), half_N);
	MM[3] = mul(AA[1][1], mie(BB[1][0], BB[0][0], half_N), half_N);
	MM[4] = mul(add(AA[0][0], AA[0][1], half_N), BB[1][1], half_N);
	MM[5] = mul(mie(AA[1][0], AA[0][0], half_N), add(BB[0][0], BB[0][1], half_N), half_N);
	MM[6] = mul(mie(AA[0][1], AA[1][1], half_N), add(BB[1][0], BB[1][1], half_N), half_N);

	CC[0][0] = add(add(MM[0], MM[3], half_N), mie(MM[6], MM[4], half_N), half_N);
	CC[0][1] = add(MM[2], MM[4], half_N);
	CC[1][0] = add(MM[1], MM[3], half_N);
	CC[1][1] = add(add(MM[0], MM[2], half_N), mie(MM[5], MM[1], half_N), half_N);
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way kij\nthe time with N = %d is %ldms\n", N, diff);
	trace = 0.0;
	float trace2 = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	for (int i = 0; i < half_N; i++) {
		trace += CC[0][0][i][i];
		trace += CC[1][1][i][i];
	}
	printf("the trace with N is %d kij is %f\n", N, trace);
	printf("the trace with N is %d kij is %f\n", N, trace2);
	printf("the trace with N is %d kij is %f\n", N, trace+trace2);

	
}
float rand_float(float s) {

	return 4 * s*(1 - s);
}
void matrix_gen(float *a, float *b, int N, float seed) {
	float s = seed;
	for (int i = 0; i < N*N; i++) {
		s = rand_float(s);
		a[i] = s;
		s = rand_float(s);
		b[i] = s;
	}
}
void matrmul(float *A, float *B, int N) {
	float *C = new float[N*N]{ 0 };

	/*timeval start;
	timeval end;
	unsigned long diff;
	gettimeofday(&start, NULL);*/

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

	int kt;
	//
//#pragma omp parallel for num_threads(12)private(kt)
	for (int k = 0; k < N; k++) {
		kt = k * N;
		#pragma omp parallel for num_threads(12)
		for (int i = 0; i < N; i++) {
			float r = A[i*N + k];
			int it = i * N;
			for (int j = 0; j < N; j += 512) {
				C[it + j] += r * B[kt + j];
				C[it + j + 1] += r * B[kt + j + 1];
				C[it + j + 2] += r * B[kt + j + 2];
				C[it + j + 3] += r * B[kt + j + 3];
				C[it + j + 4] += r * B[kt + j + 4];
				C[it + j + 5] += r * B[kt + j + 5];
				C[it + j + 6] += r * B[kt + j + 6];
				C[it + j + 7] += r * B[kt + j + 7];
				C[it + j + 8] += r * B[kt + j + 8];
				C[it + j + 9] += r * B[kt + j + 9];
				C[it + j + 10] += r * B[kt + j + 10];
				C[it + j + 11] += r * B[kt + j + 11];
				C[it + j + 12] += r * B[kt + j + 12];
				C[it + j + 13] += r * B[kt + j + 13];
				C[it + j + 14] += r * B[kt + j + 14];
				C[it + j + 15] += r * B[kt + j + 15];
				C[it + j + 16] += r * B[kt + j + 16];
				C[it + j + 17] += r * B[kt + j + 17];
				C[it + j + 18] += r * B[kt + j + 18];
				C[it + j + 19] += r * B[kt + j + 19];
				C[it + j + 20] += r * B[kt + j + 20];
				C[it + j + 21] += r * B[kt + j + 21];
				C[it + j + 22] += r * B[kt + j + 22];
				C[it + j + 23] += r * B[kt + j + 23];
				C[it + j + 24] += r * B[kt + j + 24];
				C[it + j + 25] += r * B[kt + j + 25];
				C[it + j + 26] += r * B[kt + j + 26];
				C[it + j + 27] += r * B[kt + j + 27];
				C[it + j + 28] += r * B[kt + j + 28];
				C[it + j + 29] += r * B[kt + j + 29];
				C[it + j + 30] += r * B[kt + j + 30];
				C[it + j + 31] += r * B[kt + j + 31];
				C[it + j + 32] += r * B[kt + j + 32];
				C[it + j + 33] += r * B[kt + j + 33];
				C[it + j + 34] += r * B[kt + j + 34];
				C[it + j + 35] += r * B[kt + j + 35];
				C[it + j + 36] += r * B[kt + j + 36];
				C[it + j + 37] += r * B[kt + j + 37];
				C[it + j + 38] += r * B[kt + j + 38];
				C[it + j + 39] += r * B[kt + j + 39];
				C[it + j + 40] += r * B[kt + j + 40];
				C[it + j + 41] += r * B[kt + j + 41];
				C[it + j + 42] += r * B[kt + j + 42];
				C[it + j + 43] += r * B[kt + j + 43];
				C[it + j + 44] += r * B[kt + j + 44];
				C[it + j + 45] += r * B[kt + j + 45];
				C[it + j + 46] += r * B[kt + j + 46];
				C[it + j + 47] += r * B[kt + j + 47];
				C[it + j + 48] += r * B[kt + j + 48];
				C[it + j + 49] += r * B[kt + j + 49];
				C[it + j + 50] += r * B[kt + j + 50];
				C[it + j + 51] += r * B[kt + j + 51];
				C[it + j + 52] += r * B[kt + j + 52];
				C[it + j + 53] += r * B[kt + j + 53];
				C[it + j + 54] += r * B[kt + j + 54];
				C[it + j + 55] += r * B[kt + j + 55];
				C[it + j + 56] += r * B[kt + j + 56];
				C[it + j + 57] += r * B[kt + j + 57];
				C[it + j + 58] += r * B[kt + j + 58];
				C[it + j + 59] += r * B[kt + j + 59];
				C[it + j + 60] += r * B[kt + j + 60];
				C[it + j + 61] += r * B[kt + j + 61];
				C[it + j + 62] += r * B[kt + j + 62];
				C[it + j + 63] += r * B[kt + j + 63];
				C[it + j + 64] += r * B[kt + j + 64];
				C[it + j + 65] += r * B[kt + j + 65];
				C[it + j + 66] += r * B[kt + j + 66];
				C[it + j + 67] += r * B[kt + j + 67];
				C[it + j + 68] += r * B[kt + j + 68];
				C[it + j + 69] += r * B[kt + j + 69];
				C[it + j + 70] += r * B[kt + j + 70];
				C[it + j + 71] += r * B[kt + j + 71];
				C[it + j + 72] += r * B[kt + j + 72];
				C[it + j + 73] += r * B[kt + j + 73];
				C[it + j + 74] += r * B[kt + j + 74];
				C[it + j + 75] += r * B[kt + j + 75];
				C[it + j + 76] += r * B[kt + j + 76];
				C[it + j + 77] += r * B[kt + j + 77];
				C[it + j + 78] += r * B[kt + j + 78];
				C[it + j + 79] += r * B[kt + j + 79];
				C[it + j + 80] += r * B[kt + j + 80];
				C[it + j + 81] += r * B[kt + j + 81];
				C[it + j + 82] += r * B[kt + j + 82];
				C[it + j + 83] += r * B[kt + j + 83];
				C[it + j + 84] += r * B[kt + j + 84];
				C[it + j + 85] += r * B[kt + j + 85];
				C[it + j + 86] += r * B[kt + j + 86];
				C[it + j + 87] += r * B[kt + j + 87];
				C[it + j + 88] += r * B[kt + j + 88];
				C[it + j + 89] += r * B[kt + j + 89];
				C[it + j + 90] += r * B[kt + j + 90];
				C[it + j + 91] += r * B[kt + j + 91];
				C[it + j + 92] += r * B[kt + j + 92];
				C[it + j + 93] += r * B[kt + j + 93];
				C[it + j + 94] += r * B[kt + j + 94];
				C[it + j + 95] += r * B[kt + j + 95];
				C[it + j + 96] += r * B[kt + j + 96];
				C[it + j + 97] += r * B[kt + j + 97];
				C[it + j + 98] += r * B[kt + j + 98];
				C[it + j + 99] += r * B[kt + j + 99];
				C[it + j + 100] += r * B[kt + j + 100];
				C[it + j + 101] += r * B[kt + j + 101];
				C[it + j + 102] += r * B[kt + j + 102];
				C[it + j + 103] += r * B[kt + j + 103];
				C[it + j + 104] += r * B[kt + j + 104];
				C[it + j + 105] += r * B[kt + j + 105];
				C[it + j + 106] += r * B[kt + j + 106];
				C[it + j + 107] += r * B[kt + j + 107];
				C[it + j + 108] += r * B[kt + j + 108];
				C[it + j + 109] += r * B[kt + j + 109];
				C[it + j + 110] += r * B[kt + j + 110];
				C[it + j + 111] += r * B[kt + j + 111];
				C[it + j + 112] += r * B[kt + j + 112];
				C[it + j + 113] += r * B[kt + j + 113];
				C[it + j + 114] += r * B[kt + j + 114];
				C[it + j + 115] += r * B[kt + j + 115];
				C[it + j + 116] += r * B[kt + j + 116];
				C[it + j + 117] += r * B[kt + j + 117];
				C[it + j + 118] += r * B[kt + j + 118];
				C[it + j + 119] += r * B[kt + j + 119];
				C[it + j + 120] += r * B[kt + j + 120];
				C[it + j + 121] += r * B[kt + j + 121];
				C[it + j + 122] += r * B[kt + j + 122];
				C[it + j + 123] += r * B[kt + j + 123];
				C[it + j + 124] += r * B[kt + j + 124];
				C[it + j + 125] += r * B[kt + j + 125];
				C[it + j + 126] += r * B[kt + j + 126];
				C[it + j + 127] += r * B[kt + j + 127];
				C[it + j + 128] += r * B[kt + j + 128];
				C[it + j + 129] += r * B[kt + j + 129];
				C[it + j + 130] += r * B[kt + j + 130];
				C[it + j + 131] += r * B[kt + j + 131];
				C[it + j + 132] += r * B[kt + j + 132];
				C[it + j + 133] += r * B[kt + j + 133];
				C[it + j + 134] += r * B[kt + j + 134];
				C[it + j + 135] += r * B[kt + j + 135];
				C[it + j + 136] += r * B[kt + j + 136];
				C[it + j + 137] += r * B[kt + j + 137];
				C[it + j + 138] += r * B[kt + j + 138];
				C[it + j + 139] += r * B[kt + j + 139];
				C[it + j + 140] += r * B[kt + j + 140];
				C[it + j + 141] += r * B[kt + j + 141];
				C[it + j + 142] += r * B[kt + j + 142];
				C[it + j + 143] += r * B[kt + j + 143];
				C[it + j + 144] += r * B[kt + j + 144];
				C[it + j + 145] += r * B[kt + j + 145];
				C[it + j + 146] += r * B[kt + j + 146];
				C[it + j + 147] += r * B[kt + j + 147];
				C[it + j + 148] += r * B[kt + j + 148];
				C[it + j + 149] += r * B[kt + j + 149];
				C[it + j + 150] += r * B[kt + j + 150];
				C[it + j + 151] += r * B[kt + j + 151];
				C[it + j + 152] += r * B[kt + j + 152];
				C[it + j + 153] += r * B[kt + j + 153];
				C[it + j + 154] += r * B[kt + j + 154];
				C[it + j + 155] += r * B[kt + j + 155];
				C[it + j + 156] += r * B[kt + j + 156];
				C[it + j + 157] += r * B[kt + j + 157];
				C[it + j + 158] += r * B[kt + j + 158];
				C[it + j + 159] += r * B[kt + j + 159];
				C[it + j + 160] += r * B[kt + j + 160];
				C[it + j + 161] += r * B[kt + j + 161];
				C[it + j + 162] += r * B[kt + j + 162];
				C[it + j + 163] += r * B[kt + j + 163];
				C[it + j + 164] += r * B[kt + j + 164];
				C[it + j + 165] += r * B[kt + j + 165];
				C[it + j + 166] += r * B[kt + j + 166];
				C[it + j + 167] += r * B[kt + j + 167];
				C[it + j + 168] += r * B[kt + j + 168];
				C[it + j + 169] += r * B[kt + j + 169];
				C[it + j + 170] += r * B[kt + j + 170];
				C[it + j + 171] += r * B[kt + j + 171];
				C[it + j + 172] += r * B[kt + j + 172];
				C[it + j + 173] += r * B[kt + j + 173];
				C[it + j + 174] += r * B[kt + j + 174];
				C[it + j + 175] += r * B[kt + j + 175];
				C[it + j + 176] += r * B[kt + j + 176];
				C[it + j + 177] += r * B[kt + j + 177];
				C[it + j + 178] += r * B[kt + j + 178];
				C[it + j + 179] += r * B[kt + j + 179];
				C[it + j + 180] += r * B[kt + j + 180];
				C[it + j + 181] += r * B[kt + j + 181];
				C[it + j + 182] += r * B[kt + j + 182];
				C[it + j + 183] += r * B[kt + j + 183];
				C[it + j + 184] += r * B[kt + j + 184];
				C[it + j + 185] += r * B[kt + j + 185];
				C[it + j + 186] += r * B[kt + j + 186];
				C[it + j + 187] += r * B[kt + j + 187];
				C[it + j + 188] += r * B[kt + j + 188];
				C[it + j + 189] += r * B[kt + j + 189];
				C[it + j + 190] += r * B[kt + j + 190];
				C[it + j + 191] += r * B[kt + j + 191];
				C[it + j + 192] += r * B[kt + j + 192];
				C[it + j + 193] += r * B[kt + j + 193];
				C[it + j + 194] += r * B[kt + j + 194];
				C[it + j + 195] += r * B[kt + j + 195];
				C[it + j + 196] += r * B[kt + j + 196];
				C[it + j + 197] += r * B[kt + j + 197];
				C[it + j + 198] += r * B[kt + j + 198];
				C[it + j + 199] += r * B[kt + j + 199];
				C[it + j + 200] += r * B[kt + j + 200];
				C[it + j + 201] += r * B[kt + j + 201];
				C[it + j + 202] += r * B[kt + j + 202];
				C[it + j + 203] += r * B[kt + j + 203];
				C[it + j + 204] += r * B[kt + j + 204];
				C[it + j + 205] += r * B[kt + j + 205];
				C[it + j + 206] += r * B[kt + j + 206];
				C[it + j + 207] += r * B[kt + j + 207];
				C[it + j + 208] += r * B[kt + j + 208];
				C[it + j + 209] += r * B[kt + j + 209];
				C[it + j + 210] += r * B[kt + j + 210];
				C[it + j + 211] += r * B[kt + j + 211];
				C[it + j + 212] += r * B[kt + j + 212];
				C[it + j + 213] += r * B[kt + j + 213];
				C[it + j + 214] += r * B[kt + j + 214];
				C[it + j + 215] += r * B[kt + j + 215];
				C[it + j + 216] += r * B[kt + j + 216];
				C[it + j + 217] += r * B[kt + j + 217];
				C[it + j + 218] += r * B[kt + j + 218];
				C[it + j + 219] += r * B[kt + j + 219];
				C[it + j + 220] += r * B[kt + j + 220];
				C[it + j + 221] += r * B[kt + j + 221];
				C[it + j + 222] += r * B[kt + j + 222];
				C[it + j + 223] += r * B[kt + j + 223];
				C[it + j + 224] += r * B[kt + j + 224];
				C[it + j + 225] += r * B[kt + j + 225];
				C[it + j + 226] += r * B[kt + j + 226];
				C[it + j + 227] += r * B[kt + j + 227];
				C[it + j + 228] += r * B[kt + j + 228];
				C[it + j + 229] += r * B[kt + j + 229];
				C[it + j + 230] += r * B[kt + j + 230];
				C[it + j + 231] += r * B[kt + j + 231];
				C[it + j + 232] += r * B[kt + j + 232];
				C[it + j + 233] += r * B[kt + j + 233];
				C[it + j + 234] += r * B[kt + j + 234];
				C[it + j + 235] += r * B[kt + j + 235];
				C[it + j + 236] += r * B[kt + j + 236];
				C[it + j + 237] += r * B[kt + j + 237];
				C[it + j + 238] += r * B[kt + j + 238];
				C[it + j + 239] += r * B[kt + j + 239];
				C[it + j + 240] += r * B[kt + j + 240];
				C[it + j + 241] += r * B[kt + j + 241];
				C[it + j + 242] += r * B[kt + j + 242];
				C[it + j + 243] += r * B[kt + j + 243];
				C[it + j + 244] += r * B[kt + j + 244];
				C[it + j + 245] += r * B[kt + j + 245];
				C[it + j + 246] += r * B[kt + j + 246];
				C[it + j + 247] += r * B[kt + j + 247];
				C[it + j + 248] += r * B[kt + j + 248];
				C[it + j + 249] += r * B[kt + j + 249];
				C[it + j + 250] += r * B[kt + j + 250];
				C[it + j + 251] += r * B[kt + j + 251];
				C[it + j + 252] += r * B[kt + j + 252];
				C[it + j + 253] += r * B[kt + j + 253];
				C[it + j + 254] += r * B[kt + j + 254];
				C[it + j + 255] += r * B[kt + j + 255];
				C[it + j + 256] += r * B[kt + j + 256];
				C[it + j + 257] += r * B[kt + j + 257];
				C[it + j + 258] += r * B[kt + j + 258];
				C[it + j + 259] += r * B[kt + j + 259];
				C[it + j + 260] += r * B[kt + j + 260];
				C[it + j + 261] += r * B[kt + j + 261];
				C[it + j + 262] += r * B[kt + j + 262];
				C[it + j + 263] += r * B[kt + j + 263];
				C[it + j + 264] += r * B[kt + j + 264];
				C[it + j + 265] += r * B[kt + j + 265];
				C[it + j + 266] += r * B[kt + j + 266];
				C[it + j + 267] += r * B[kt + j + 267];
				C[it + j + 268] += r * B[kt + j + 268];
				C[it + j + 269] += r * B[kt + j + 269];
				C[it + j + 270] += r * B[kt + j + 270];
				C[it + j + 271] += r * B[kt + j + 271];
				C[it + j + 272] += r * B[kt + j + 272];
				C[it + j + 273] += r * B[kt + j + 273];
				C[it + j + 274] += r * B[kt + j + 274];
				C[it + j + 275] += r * B[kt + j + 275];
				C[it + j + 276] += r * B[kt + j + 276];
				C[it + j + 277] += r * B[kt + j + 277];
				C[it + j + 278] += r * B[kt + j + 278];
				C[it + j + 279] += r * B[kt + j + 279];
				C[it + j + 280] += r * B[kt + j + 280];
				C[it + j + 281] += r * B[kt + j + 281];
				C[it + j + 282] += r * B[kt + j + 282];
				C[it + j + 283] += r * B[kt + j + 283];
				C[it + j + 284] += r * B[kt + j + 284];
				C[it + j + 285] += r * B[kt + j + 285];
				C[it + j + 286] += r * B[kt + j + 286];
				C[it + j + 287] += r * B[kt + j + 287];
				C[it + j + 288] += r * B[kt + j + 288];
				C[it + j + 289] += r * B[kt + j + 289];
				C[it + j + 290] += r * B[kt + j + 290];
				C[it + j + 291] += r * B[kt + j + 291];
				C[it + j + 292] += r * B[kt + j + 292];
				C[it + j + 293] += r * B[kt + j + 293];
				C[it + j + 294] += r * B[kt + j + 294];
				C[it + j + 295] += r * B[kt + j + 295];
				C[it + j + 296] += r * B[kt + j + 296];
				C[it + j + 297] += r * B[kt + j + 297];
				C[it + j + 298] += r * B[kt + j + 298];
				C[it + j + 299] += r * B[kt + j + 299];
				C[it + j + 300] += r * B[kt + j + 300];
				C[it + j + 301] += r * B[kt + j + 301];
				C[it + j + 302] += r * B[kt + j + 302];
				C[it + j + 303] += r * B[kt + j + 303];
				C[it + j + 304] += r * B[kt + j + 304];
				C[it + j + 305] += r * B[kt + j + 305];
				C[it + j + 306] += r * B[kt + j + 306];
				C[it + j + 307] += r * B[kt + j + 307];
				C[it + j + 308] += r * B[kt + j + 308];
				C[it + j + 309] += r * B[kt + j + 309];
				C[it + j + 310] += r * B[kt + j + 310];
				C[it + j + 311] += r * B[kt + j + 311];
				C[it + j + 312] += r * B[kt + j + 312];
				C[it + j + 313] += r * B[kt + j + 313];
				C[it + j + 314] += r * B[kt + j + 314];
				C[it + j + 315] += r * B[kt + j + 315];
				C[it + j + 316] += r * B[kt + j + 316];
				C[it + j + 317] += r * B[kt + j + 317];
				C[it + j + 318] += r * B[kt + j + 318];
				C[it + j + 319] += r * B[kt + j + 319];
				C[it + j + 320] += r * B[kt + j + 320];
				C[it + j + 321] += r * B[kt + j + 321];
				C[it + j + 322] += r * B[kt + j + 322];
				C[it + j + 323] += r * B[kt + j + 323];
				C[it + j + 324] += r * B[kt + j + 324];
				C[it + j + 325] += r * B[kt + j + 325];
				C[it + j + 326] += r * B[kt + j + 326];
				C[it + j + 327] += r * B[kt + j + 327];
				C[it + j + 328] += r * B[kt + j + 328];
				C[it + j + 329] += r * B[kt + j + 329];
				C[it + j + 330] += r * B[kt + j + 330];
				C[it + j + 331] += r * B[kt + j + 331];
				C[it + j + 332] += r * B[kt + j + 332];
				C[it + j + 333] += r * B[kt + j + 333];
				C[it + j + 334] += r * B[kt + j + 334];
				C[it + j + 335] += r * B[kt + j + 335];
				C[it + j + 336] += r * B[kt + j + 336];
				C[it + j + 337] += r * B[kt + j + 337];
				C[it + j + 338] += r * B[kt + j + 338];
				C[it + j + 339] += r * B[kt + j + 339];
				C[it + j + 340] += r * B[kt + j + 340];
				C[it + j + 341] += r * B[kt + j + 341];
				C[it + j + 342] += r * B[kt + j + 342];
				C[it + j + 343] += r * B[kt + j + 343];
				C[it + j + 344] += r * B[kt + j + 344];
				C[it + j + 345] += r * B[kt + j + 345];
				C[it + j + 346] += r * B[kt + j + 346];
				C[it + j + 347] += r * B[kt + j + 347];
				C[it + j + 348] += r * B[kt + j + 348];
				C[it + j + 349] += r * B[kt + j + 349];
				C[it + j + 350] += r * B[kt + j + 350];
				C[it + j + 351] += r * B[kt + j + 351];
				C[it + j + 352] += r * B[kt + j + 352];
				C[it + j + 353] += r * B[kt + j + 353];
				C[it + j + 354] += r * B[kt + j + 354];
				C[it + j + 355] += r * B[kt + j + 355];
				C[it + j + 356] += r * B[kt + j + 356];
				C[it + j + 357] += r * B[kt + j + 357];
				C[it + j + 358] += r * B[kt + j + 358];
				C[it + j + 359] += r * B[kt + j + 359];
				C[it + j + 360] += r * B[kt + j + 360];
				C[it + j + 361] += r * B[kt + j + 361];
				C[it + j + 362] += r * B[kt + j + 362];
				C[it + j + 363] += r * B[kt + j + 363];
				C[it + j + 364] += r * B[kt + j + 364];
				C[it + j + 365] += r * B[kt + j + 365];
				C[it + j + 366] += r * B[kt + j + 366];
				C[it + j + 367] += r * B[kt + j + 367];
				C[it + j + 368] += r * B[kt + j + 368];
				C[it + j + 369] += r * B[kt + j + 369];
				C[it + j + 370] += r * B[kt + j + 370];
				C[it + j + 371] += r * B[kt + j + 371];
				C[it + j + 372] += r * B[kt + j + 372];
				C[it + j + 373] += r * B[kt + j + 373];
				C[it + j + 374] += r * B[kt + j + 374];
				C[it + j + 375] += r * B[kt + j + 375];
				C[it + j + 376] += r * B[kt + j + 376];
				C[it + j + 377] += r * B[kt + j + 377];
				C[it + j + 378] += r * B[kt + j + 378];
				C[it + j + 379] += r * B[kt + j + 379];
				C[it + j + 380] += r * B[kt + j + 380];
				C[it + j + 381] += r * B[kt + j + 381];
				C[it + j + 382] += r * B[kt + j + 382];
				C[it + j + 383] += r * B[kt + j + 383];
				C[it + j + 384] += r * B[kt + j + 384];
				C[it + j + 385] += r * B[kt + j + 385];
				C[it + j + 386] += r * B[kt + j + 386];
				C[it + j + 387] += r * B[kt + j + 387];
				C[it + j + 388] += r * B[kt + j + 388];
				C[it + j + 389] += r * B[kt + j + 389];
				C[it + j + 390] += r * B[kt + j + 390];
				C[it + j + 391] += r * B[kt + j + 391];
				C[it + j + 392] += r * B[kt + j + 392];
				C[it + j + 393] += r * B[kt + j + 393];
				C[it + j + 394] += r * B[kt + j + 394];
				C[it + j + 395] += r * B[kt + j + 395];
				C[it + j + 396] += r * B[kt + j + 396];
				C[it + j + 397] += r * B[kt + j + 397];
				C[it + j + 398] += r * B[kt + j + 398];
				C[it + j + 399] += r * B[kt + j + 399];
				C[it + j + 400] += r * B[kt + j + 400];
				C[it + j + 401] += r * B[kt + j + 401];
				C[it + j + 402] += r * B[kt + j + 402];
				C[it + j + 403] += r * B[kt + j + 403];
				C[it + j + 404] += r * B[kt + j + 404];
				C[it + j + 405] += r * B[kt + j + 405];
				C[it + j + 406] += r * B[kt + j + 406];
				C[it + j + 407] += r * B[kt + j + 407];
				C[it + j + 408] += r * B[kt + j + 408];
				C[it + j + 409] += r * B[kt + j + 409];
				C[it + j + 410] += r * B[kt + j + 410];
				C[it + j + 411] += r * B[kt + j + 411];
				C[it + j + 412] += r * B[kt + j + 412];
				C[it + j + 413] += r * B[kt + j + 413];
				C[it + j + 414] += r * B[kt + j + 414];
				C[it + j + 415] += r * B[kt + j + 415];
				C[it + j + 416] += r * B[kt + j + 416];
				C[it + j + 417] += r * B[kt + j + 417];
				C[it + j + 418] += r * B[kt + j + 418];
				C[it + j + 419] += r * B[kt + j + 419];
				C[it + j + 420] += r * B[kt + j + 420];
				C[it + j + 421] += r * B[kt + j + 421];
				C[it + j + 422] += r * B[kt + j + 422];
				C[it + j + 423] += r * B[kt + j + 423];
				C[it + j + 424] += r * B[kt + j + 424];
				C[it + j + 425] += r * B[kt + j + 425];
				C[it + j + 426] += r * B[kt + j + 426];
				C[it + j + 427] += r * B[kt + j + 427];
				C[it + j + 428] += r * B[kt + j + 428];
				C[it + j + 429] += r * B[kt + j + 429];
				C[it + j + 430] += r * B[kt + j + 430];
				C[it + j + 431] += r * B[kt + j + 431];
				C[it + j + 432] += r * B[kt + j + 432];
				C[it + j + 433] += r * B[kt + j + 433];
				C[it + j + 434] += r * B[kt + j + 434];
				C[it + j + 435] += r * B[kt + j + 435];
				C[it + j + 436] += r * B[kt + j + 436];
				C[it + j + 437] += r * B[kt + j + 437];
				C[it + j + 438] += r * B[kt + j + 438];
				C[it + j + 439] += r * B[kt + j + 439];
				C[it + j + 440] += r * B[kt + j + 440];
				C[it + j + 441] += r * B[kt + j + 441];
				C[it + j + 442] += r * B[kt + j + 442];
				C[it + j + 443] += r * B[kt + j + 443];
				C[it + j + 444] += r * B[kt + j + 444];
				C[it + j + 445] += r * B[kt + j + 445];
				C[it + j + 446] += r * B[kt + j + 446];
				C[it + j + 447] += r * B[kt + j + 447];
				C[it + j + 448] += r * B[kt + j + 448];
				C[it + j + 449] += r * B[kt + j + 449];
				C[it + j + 450] += r * B[kt + j + 450];
				C[it + j + 451] += r * B[kt + j + 451];
				C[it + j + 452] += r * B[kt + j + 452];
				C[it + j + 453] += r * B[kt + j + 453];
				C[it + j + 454] += r * B[kt + j + 454];
				C[it + j + 455] += r * B[kt + j + 455];
				C[it + j + 456] += r * B[kt + j + 456];
				C[it + j + 457] += r * B[kt + j + 457];
				C[it + j + 458] += r * B[kt + j + 458];
				C[it + j + 459] += r * B[kt + j + 459];
				C[it + j + 460] += r * B[kt + j + 460];
				C[it + j + 461] += r * B[kt + j + 461];
				C[it + j + 462] += r * B[kt + j + 462];
				C[it + j + 463] += r * B[kt + j + 463];
				C[it + j + 464] += r * B[kt + j + 464];
				C[it + j + 465] += r * B[kt + j + 465];
				C[it + j + 466] += r * B[kt + j + 466];
				C[it + j + 467] += r * B[kt + j + 467];
				C[it + j + 468] += r * B[kt + j + 468];
				C[it + j + 469] += r * B[kt + j + 469];
				C[it + j + 470] += r * B[kt + j + 470];
				C[it + j + 471] += r * B[kt + j + 471];
				C[it + j + 472] += r * B[kt + j + 472];
				C[it + j + 473] += r * B[kt + j + 473];
				C[it + j + 474] += r * B[kt + j + 474];
				C[it + j + 475] += r * B[kt + j + 475];
				C[it + j + 476] += r * B[kt + j + 476];
				C[it + j + 477] += r * B[kt + j + 477];
				C[it + j + 478] += r * B[kt + j + 478];
				C[it + j + 479] += r * B[kt + j + 479];
				C[it + j + 480] += r * B[kt + j + 480];
				C[it + j + 481] += r * B[kt + j + 481];
				C[it + j + 482] += r * B[kt + j + 482];
				C[it + j + 483] += r * B[kt + j + 483];
				C[it + j + 484] += r * B[kt + j + 484];
				C[it + j + 485] += r * B[kt + j + 485];
				C[it + j + 486] += r * B[kt + j + 486];
				C[it + j + 487] += r * B[kt + j + 487];
				C[it + j + 488] += r * B[kt + j + 488];
				C[it + j + 489] += r * B[kt + j + 489];
				C[it + j + 490] += r * B[kt + j + 490];
				C[it + j + 491] += r * B[kt + j + 491];
				C[it + j + 492] += r * B[kt + j + 492];
				C[it + j + 493] += r * B[kt + j + 493];
				C[it + j + 494] += r * B[kt + j + 494];
				C[it + j + 495] += r * B[kt + j + 495];
				C[it + j + 496] += r * B[kt + j + 496];
				C[it + j + 497] += r * B[kt + j + 497];
				C[it + j + 498] += r * B[kt + j + 498];
				C[it + j + 499] += r * B[kt + j + 499];
				C[it + j + 500] += r * B[kt + j + 500];
				C[it + j + 501] += r * B[kt + j + 501];
				C[it + j + 502] += r * B[kt + j + 502];
				C[it + j + 503] += r * B[kt + j + 503];
				C[it + j + 504] += r * B[kt + j + 504];
				C[it + j + 505] += r * B[kt + j + 505];
				C[it + j + 506] += r * B[kt + j + 506];
				C[it + j + 507] += r * B[kt + j + 507];
				C[it + j + 508] += r * B[kt + j + 508];
				C[it + j + 509] += r * B[kt + j + 509];
				C[it + j + 510] += r * B[kt + j + 510];
				C[it + j + 511] += r * B[kt + j + 511];
			}
		}
	}
	/*gettimeofday(&end, NULL);
	diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;
*/
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way kij\nthe time with N = %d is %ldms\n", N, diff);


	//printf("the difference with N is %d kij is %ld\n", N, diff);
	float trace = 0.0;
	float trace2 = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	int half_N = N / 2;
	float trace3 = 0.0;
	int str=(half_N*(N+1));
	for (int i = 0; i < N; i++) {
		trace3 += C[i*N + i];
	}
	printf("the trace with N is %d kij is %f\n", N, trace3);

	delete C;
}
inline void Batch_matrmul(float* A,float *B,int sub_size,int N) {
	int sub_num = N / sub_size;
	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

	float **mat_A = new float *[sub_num*sub_num]; 
	float **mat_B = new float *[sub_num*sub_num];
	float **mat_C = new float *[sub_num*sub_num];
	int size = sub_size * sub_size;


	for (int i = 0; i < sub_num; i++) {
		mat_A[i] = new float[size];
		mat_B[i] = new float[size];
		mat_C[i] = new float[size] {0.0};
	}
	for (int r = 0; r < N*N; r++) {
		int i = r / (size*sub_num);
		int j = (r - i * N * sub_size) % sub_size;
		mat_A[i][j] = A[r];
		mat_B[i][j] = B[r];
	}
	for (int k_C = 0; k_C < sub_num; k_C++) {
		int kp = k_C * sub_num;
		for (int i = 0; i < sub_num; i++) {
			int im = i * sub_num;
			for (int j = 0; j < sub_num; j++) {
				//����������Ϊ�˼����i�У�j�е�C����
				//Ҳ���Ǽ���mat_Cij�������ʹ�õ���mat_Aik_C**mat_Bk_Cj
				//��Ϊ����ʹ�õ�˹kij������������k�ξ���ӷ�ȥ��
				//�õ�һ��mat_Cij+=mat_Aik*mat_Bkj
				for (int k = 0; k < sub_size; k++)
				{
					//���������ʵ������Ϊ��ȥ�������mat_Cij��һ������
					//������ȥʹ�õ�Cmn+=Amk*Bkn
					int kk = k * sub_size;
					for (int m = 0; m < sub_size; m++) {
						int m_t = m * sub_size;
						float r = mat_A[im + k_C][m_t + k];
						for (int n = 0; n < sub_size; n++) {
							mat_C[im + j][m_t + n] += r*mat_B[kp+n][kk+n];
						}
					}
				}
			}
		}
	}

	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ld\n", N, diff);
	float trace = 0.0;
	for (int i = 0; i < sub_num; i++) {
		int i_co = i * sub_num;
		for (int j = 0; j < sub_size; j++) {
			trace += mat_C[i_co + i][j*sub_size + j];
		}
	}
	printf("the trace with N is %d kij is %f\n", N, trace);
}
void norm(float * A, float *B, int N){
	float *C = new float[N*N]{ 0 };

	//timeval start;
	//timeval end;
	//unsigned long diff;
	//gettimeofday(&start, NULL);

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

#pragma omp parallel for num_threads(12)
	for (int i = 0; i < N; i++) {
		int it = i * N;
		for (int j = 0; j < N; j++) {
			int jt = j * N;
			for (int k = 0; k < N; k++) {
				C[it + j] += A[it + k] * B[k*N + j];
			}
		}
	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way ijk\nthe time with N = %d is %ldms\n", N, diff);


	//printf("the difference with N is %d kij is %ld\n", N, diff);
	float trace = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	for (int i = 0; i < N; i++) {
		trace += C[i*N + i];
	}

	printf("the trace with N is %d kij is %f\n", N, trace);

	delete C;

}
void norm2(float * A, float *B, int N) {
	float *C = new float[N*N]{ 0 };

	//timeval start;
	//timeval end;
	//unsigned long diff;
	//gettimeofday(&start, NULL);

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;
#pragma omp parallel for num_threads(12)
	for (int i = 0; i < N; i++) {
		int it = i * N;
		for (int k = 0; k < N; k++) {
			int kt = k * N;
			for (int j = 0; j < N; j++) {
				C[it + j] += A[it + k] * B[k*N + j];
			}
		}
	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("way ikj\nthe time with N = %d is %ldms\n", N, diff);


	//printf("the difference with N is %d kij is %ld\n", N, diff);
	float trace = 0.0;
	//#pragma omp parallel for num_threads(8)reduction(+:trace)
	for (int i = 0; i < N; i++) {
		trace += C[i*N + i];
	}

	printf("the trace with N is %d kij is %f\n", N, trace);
	delete C;

}

/*
�ֿ鷵��һ����СΪbatch*batch��ָ��
�������壺
M:�������
N:����ĳ���
batch:����ĳ���
num:����ľ�������
*/
float* fenkuai(float *M,  int N, int batch,int num) {
	int size = batch * batch;
	float *result = new float[size];
	int line=N/batch;
	int row, column;
	row = num / line;
	column = num - row * line;
	int start;
	int rowsize = N * batch;
	start = rowsize * row+column*batch;
	int i = 0;
	for (int j = 0; j < batch; j++) {
		int jj = j * N;
		start += jj;
		for (int k = 0; k < batch; k++) {
			result[i++] = M[start+k];
		}
	}
	return result;
}

void ComputeArraySSE(float* pArray1, float* pArray2,  int N) {
	int nLoop;
	int i = 0;
	int j = 0;
	__m128 m1, m2, m3, mx;
	float* pResult = new float[N*N]{ 0.0 };
	float* p1;
	float* p2;
	float* pr;
	p1 = pArray1;
	p2 = pArray2;
	pr = pResult;
	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;

//#pragma omp parallel for num_threads(12)
	for (int k = 0; k < N; k++) {
		int kk = k * N;

		for (int i = 0; i < N; i++) {
			int ii = i * N;
			m1 = _mm_load1_ps(p1 + ii + k);

			for (int j = 0; j < N; j += 4) {
				m2 = _mm_loadu_ps(p2+j+kk);
				m3 = _mm_loadu_ps(pr+j+ii);
				mx = _mm_mul_ps(m1, m2);
				m3 = _mm_add_ps(m3, mx);
				_mm_storeu_ps(pResult+j+ii, m3);
			}
		}
	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ldms\n", N, diff);

	float trace = 0.0;
	for (int i = 0; i < N; i++) {
		trace += pResult[i + i * N];
	}
	printf("trace is %f\n", trace);
}
void ComputeArraySSE2(float* pArray1, float* pArray2, int N) {
	int nLoop;
	int i = 0;
	int j = 0;
	__m128 m1, m2, m3, mx;
	float* pResult = new float[N*N]{ 0.0 };
	float* p1;
	float* p2;
	float* pr;
	p1 = pArray1;
	p2 = pArray2;
	pr = pResult;

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;
//#pragma omp parallel for num_threads(12) private(m1,m2,m3,mx)
	for (int k = 0; k < N; k++) {
		int kk = k * N;
//#pragma omp parallel for num_threads(12)
		for (int i = 0; i < N; i++) {
			int ii = i * N;
			m1 = _mm_load1_ps(p1 + ii + k);
			for (int j = 0; j < N; j += 4) {
				m2 = _mm_loadu_ps(p2 + j + kk);
				m3 = _mm_loadu_ps(pr + j + ii);
				mx = _mm_mul_ps(m1, m2);
				m3 = _mm_add_ps(m3, mx);
				_mm_storeu_ps(pResult + j + ii, m3);
			}
		}
	}

	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ldms\n", N, diff);
	float trace = 0.0;
	for (int i = 0; i < N; i++) {
		trace += pResult[i + i * N];
	}
	printf("trace is %f\n", trace);
}
void ComputeArraySSE3(float* pArray1, float* pArray2, int N) {

	__m128 m1, m2, m3, mx;
	float* pResult = new float[N*N]{ 0.0 };
	float* p1;
	float* p2;
	float* pr;
	p1 = pArray1;
	pr = pResult;
	__m128 *m = new __m128[N/4];
	int count = N / 4;

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;
	//#pragma omp parallel for num_threads(12) private(m1,m2,m3,mx)
	for (int i = 0; i < N; i++) {
		int ii = i * N;
		//#pragma omp parallel for num_threads(12)
		float *s = pResult+ii;
		//load C
		for (int row = 0; row < count; row++) {
			m[row] = _mm_loadu_ps(pr);
			pr += 4;
		}
		pr = s;
		float *p2 = pArray2;
//#pragma omp parallel for num_threads(12)private(m1,m2,mx,p2)
		for (int k = 0; k < N; k++) {
			m1= _mm_load1_ps(p1+k);
			
			for (int j = 0; j < count; ++j) {
				m2 = _mm_loadu_ps(p2);
				mx = _mm_mul_ps(m1, m2);
				m[j] = _mm_add_ps(m[j], mx);
				p2 += 4;
			}
			
		}
		p1 += N;
		for (int row = 0; row < count; row++) {
			_mm_storeu_ps(pr, m[row]);
			pr += 4;
		}

	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ldms\n", N, diff);
	float trace = 0.0;
	for (int i = 0; i < N; i++) {
		trace += pResult[i + i * N];
	}
	printf("trace is %f\n", trace);
}
void ComputeArraySSE4(float* pArray1, float* pArray2, int N) {
	int count = N / 4;
	__m128 m1, m2, m3, mx;
	float* pResult = new float[N*N]{ 0.0 };
	float* p1;
	float* p2;
	float* pr;
	p1 = pArray1;
	p2 = pArray2;
	pr = pResult;
	__m128 **m = new __m128*[N];
	for (int i = 0; i < N; i++) {
		m[i] = new __m128[count];
	}
	

	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;
#pragma omp parallel for num_threads(12)
	for (int i = 0; i < N; i++) {
		int ii = i * N;
		for (int j = 0; j < count; j += 4) {
			m[i][j] = _mm_loadu_ps(pr+ii+j);
		}
	}
	pr = pResult;
//#pragma omp parallel for num_threads(12)
	for (int k = 0; k < N; k++) {
		int kk = k * N;
		for (int i = 0; i < N; i++) {
			int ii = i * N;
			m1 = _mm_load1_ps(p1 + ii + k);
			for (int j = 0; j < count; j+=4) {
				m2 = _mm_loadu_ps(p2+kk+j);
				mx = _mm_mul_ps(m1, m2);
				m[i][j] = _mm_add_ps(m[i][j], mx);
			}
		}
	}

	
#pragma omp parallel for num_threads(12)
	for (int i = 0; i < N; i++) {
		int ii = i * N;
		for (int j = 0; j < count; j += 4) {
			_mm_storeu_ps(pr+ii+j, m[i][j]);
		}
	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ldms\n", N, diff);
	float trace = 0.0;
	for (int i = 0; i < N; i++) {
		trace += pResult[i + i * N];
	}
	printf("trace is %f\n", trace);
}


void ComputeArrayAVX(float *A, float *B, int N) {
	__m256 ma, mb, mc, mx;
	float* pResult = new float[N*N]{ 0.0 };
	float* p1;
	float* p2;
	float* pr;
	p1 = A;
	p2 = B;
	pr = pResult;
	LARGE_INTEGER large_interger;
	double freq;
	__int64 diff;
	__int64 start, end;
	QueryPerformanceFrequency(&large_interger);
	freq = large_interger.QuadPart;
	QueryPerformanceCounter(&large_interger);
	start = large_interger.QuadPart;
	//#pragma omp parallel for num_threads(12) private(m1,m2,m3,mx)
	for (int k = 0; k < N; k++) {
		int kk = k * N;
		//#pragma omp parallel for num_threads(12)
		for (int i = 0; i < N; i++) {
			int ii = i * N;
			float r = A[ii + k];
			ma = _mm256_set1_ps(r);
			
			for (int j = 0; j < N; j += 8) {
				mb = _mm256_loadu_ps(p2 + j + kk);
				mc = _mm256_loadu_ps(pr + j + ii);
				mx = _mm256_mul_ps(ma, mb);
				mc = _mm256_add_ps(mc, mx);
				_mm256_storeu_ps(pResult + j + ii, mc);
			}
		}
	}
	QueryPerformanceCounter(&large_interger);
	end = large_interger.QuadPart;
	diff = 1000 * (end - start) / freq;
	printf("the time with N = %d is %ldms\n", N, diff);
	
	float trace = 0.0;
	for (int i = 0; i < N; i++) {
		trace += pResult[i + i * N];
	}
	printf("trace is %f\n", trace);
}
void main() {
	int N = 1024;
	float seed = 0.3;
	float * A = new float[N*N];
	float * B = new float[N*N];
	float * C = new float[N*N]{ 0.0 };
	matrix_gen(A, B, N, seed);
	ComputeArraySSE4(A, B, N);
	ComputeArraySSE3(A, B, N);
	ComputeArrayAVX(A, B, N);
	ComputeArraySSE(A, B,  N);
	
	

	matrmul(A, B, N);
	norm(A, B, N);
	norm2(A, B, N);
	delete A, B, C;
	system("PAUSE");
}