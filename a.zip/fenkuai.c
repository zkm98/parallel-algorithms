#include<omp.h>
#include<iostream>
//#include<Windows.h>
#include<sys/time.h>
#include <xmmintrin.h>
#include <tmmintrin.h>
#include <immintrin.h>
using namespace std;

#define BATCH 4

float rand_float(float s) {

	return 4 * s*(1 - s);
}
void matrix_gen(float *a, float *b, int N, float seed) {
	float s = seed;
	for (int i = 0; i < N*N; i++) {
		s = rand_float(s);
		a[i] = s;
		s = rand_float(s);
		b[i] = s;
	}
}


int main() {
	int N;
	float seed;
	N = 8192;
	seed = 0.3;
	int sub_size = 64;
	while (N < 8193) {
		float *A = new float[N*N];
		float *B = new float[N*N];
		matrix_gen(A, B, N, seed);
		

		//LARGE_INTEGER large_interger;
		//double freq;
		//__int64 diff;
		//__int64 start, end;
		//QueryPerformanceFrequency(&large_interger);
		//freq = large_interger.QuadPart;
		//QueryPerformanceCounter(&large_interger);
		//start = large_interger.QuadPart;

		timeval start;
		timeval end;
		unsigned long diff;
		gettimeofday(&start, NULL);

		int sub_num = N / sub_size;
		int sn = sub_num * sub_num;
		int size = sub_size * sub_size;
		float **mat_A = new float *[sn];
		float **mat_B = new float *[sn];
		float **mat_C = new float *[sn];

		for (int i = 0; i < sn; i++) {
			mat_A[i] = new float[size];
			mat_B[i] = new float[size];
			mat_C[i] = new float[size] {0.0};
		}

		for (int r = 0; r < N*N; r++) {
			int i = r / (N*sub_size);
			int j = ((r - (int)(r/N)*N) / sub_size);
			int mi=r/N-i*sub_size;
			int mj=r-N*(int)(r/N)-j*sub_size;
			mat_A[i*sub_num + j][mi*sub_size + mj] = A[r];
			mat_B[i*sub_num+j][mi*sub_size+mj] = B[r];
		}
		delete A, B;
		cout << "fin" << endl;

		for (int k1 = 0; k1 < sub_num; k1++) {
			int kp = k1 * sub_num;
#pragma omp parallel for num_threads(12)
			for (int i1 = 0; i1 < sub_num; i1++) {
				int im = i1 * sub_num;
				for (int j1 = 0; j1 < sub_num; j1++) {
					//����������Ϊ�˼����i�У�j�е�C����
					//Ҳ���Ǽ���mat_Cij�������ʹ�õ���mat_Aik_C**mat_Bk_Cj
					//��Ϊ����ʹ�õ�˹kij������������k�ξ���ӷ�ȥ��
					//�õ�һ��mat_Cij+=mat_Aik_C*mat_Bk_Cj
					for (int k2 = 0; k2 < sub_size; k2++)
					{
						//���������ʵ������Ϊ��ȥ�������mat_Cij��һ������
						//������ȥʹ�õ�Cmn+=Amk*Bkn
						int kk = k2 * sub_size;

						for (int m = 0; m < sub_size; m++) {
							int m_t = m * sub_size;
							float r = mat_A[im + k1][m_t + k2];
							for (int n = 0; n < sub_size; n+=16) {
								mat_C[im + j1][m_t + n] += r * mat_B[kp + j1][kk + n];
								mat_C[Cij][m_t + n + 1] += r * mat_B[Bkj][kk + n + 1];
								mat_C[Cij][m_t + n + 2] += r * mat_B[Bkj][kk + n + 2];
								mat_C[Cij][m_t + n + 3] += r * mat_B[Bkj][kk + n + 3];
								mat_C[Cij][m_t + n + 4] += r * mat_B[Bkj][kk + n + 4];
								mat_C[Cij][m_t + n + 5] += r * mat_B[Bkj][kk + n + 5];
								mat_C[Cij][m_t + n + 6] += r * mat_B[Bkj][kk + n + 6];
								mat_C[Cij][m_t + n + 7] += r * mat_B[Bkj][kk + n + 7];
								mat_C[Cij][m_t + n + 8] += r * mat_B[Bkj][kk + n + 8];
								mat_C[Cij][m_t + n + 9] += r * mat_B[Bkj][kk + n + 9];
								mat_C[Cij][m_t + n + 10] += r * mat_B[Bkj][kk + n + 10];
								mat_C[Cij][m_t + n + 11] += r * mat_B[Bkj][kk + n + 11];
								mat_C[Cij][m_t + n + 12] += r * mat_B[Bkj][kk + n + 12];
								mat_C[Cij][m_t + n + 13] += r * mat_B[Bkj][kk + n + 13];
								mat_C[Cij][m_t + n + 14] += r * mat_B[Bkj][kk + n + 14];
								mat_C[Cij][m_t + n + 15] += r * mat_B[Bkj][kk + n + 15];
							}
						}
					}
				}
			}
		}

		//QueryPerformanceCounter(&large_interger);
		//end = large_interger.QuadPart;
		//diff = 1000 * (end - start) / freq;

		gettimeofday(&end, NULL);
		diff = 1000000 * (end.tv_sec - start.tv_sec) + end.tv_usec - start.tv_usec;

		printf("the time with N = %d is %ld\n", N, diff);

		float trace = 0.0;
		for (int i = 0; i < sub_num; i++) {
			int i_co = i * sub_num+i;
			for (int j = 0; j < sub_size; j++) {
				trace += mat_C[i_co][j*sub_size + j];
			}
		}
		printf("the trace with N is %d kij is %f\n", N, trace);
		N *= 2;
		
	}

	system("PAUSE");
	return 0;
}

